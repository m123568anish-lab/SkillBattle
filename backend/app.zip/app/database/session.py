"""
=========================================================

SkillBattle

Database Session

Production SQLAlchemy 2.x Async Session

=========================================================
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

# ---------------------------------------------------------
# Database URL
# ---------------------------------------------------------

DATABASE_URL = os.getenv(

    "DATABASE_URL",

    "sqlite+aiosqlite:///./skillbattle.db",

)

# ---------------------------------------------------------
# Engine
# ---------------------------------------------------------

engine = create_async_engine(

    DATABASE_URL,

    echo=False,

    future=True,

    pool_pre_ping=True,

)

# ---------------------------------------------------------
# Session Factory
# ---------------------------------------------------------

AsyncSessionLocal = async_sessionmaker(

    bind=engine,

    class_=AsyncSession,

    expire_on_commit=False,

    autoflush=False,

    autocommit=False,

)

# ---------------------------------------------------------
# Dependency
# ---------------------------------------------------------

async def get_db() -> AsyncGenerator[AsyncSession, None]:

    async with AsyncSessionLocal() as session:

        try:

            yield session

        finally:

            await session.close()