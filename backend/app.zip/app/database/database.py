from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from app.core.config import settings

# Create SQLAlchemy Engine
engine_kwargs = {
    "pool_pre_ping": True,
    "echo": True,  # Set to False in production
}

if str(settings.DATABASE_URL).startswith("sqlite"):
    engine_kwargs["connect_args"] = {"check_same_thread": False}

engine = create_engine(settings.DATABASE_URL, **engine_kwargs)

# Session Factory
SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
)


# Dependency for FastAPI
def get_db():
    db: Session = SessionLocal()

    try:
        yield db
    finally:
        db.close()