from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.database.base import Base
from app.database.database import engine
from app.core.config import get_settings

# Models

from app.models.challenge import Challenge
from app.models.interview import InterviewAnswer, InterviewQuestion, InterviewSession
from app.models.profile import Profile
from app.models.streak import Streak

from app.models.xp import XP

# Routers
from app.api.auth.router import router as auth_router
from app.api.dashboard.router import router as dashboard_router
from app.modules.achievements.router import router as achievements_router
from app.modules.ai.router import router as ai_router
from app.modules.dashboard.router import router as dashboard_router_module
from app.modules.profile.router import router as profile_router
from app.modules.roadmap.router import router as roadmap_router
from app.modules.streak.router import router as streak_router
from app.modules.xp.router import router as xp_router
from app.modules.problem_generator.router import (
    router as problem_generator_router,
)
from app.modules.battle_coach.router import (
    router as battle_coach_router,
)
from app.modules.code_review.router import (
    router as code_review_router,
)
from app.modules.learning_engine.router import (
    router as learning_engine_router,
)
from app.modules.battle_engine.router import (
    router as battle_router,
)
from app.api.v1.router import (
    api_router,
)
from app.api.v1 import conversation_router

api_router.include_router(
    conversation_router,
)
# Middleware

from app.middleware.request_id import add_request_id
from app.middleware.timer import request_timer

# Exception
from app.core.exceptions import SkillBattleException
from app.models.roadmap import Roadmap, RoadmapTask, RoadmapWeek

from app.modules.interview.router import (
    router as interview_router,
)
from app.modules.analytics.router import (
    router as analytics_router,
)
from app.models.compiler import (
    Problem,
    TestCase,
    CodeSubmission,
)
from app.modules.compiler.router import (
    router as compiler_router,
)
from app.modules.battle.router import (
    router as battle_router,
)
from app.modules.tournament.router import (
    router as tournament_router,
)
from app.modules.anti_cheat.router import (

    router as anti_cheat_router,

)
from app.modules.analytics.router import (
    router as analytics_router,
)
from app.middleware.request_logger import (
    RequestLoggerMiddleware,
)
from app.modules.recruiter.router import (
    router as recruiter_router,
)
from app.modules.developer.router import (
    router as developer_router,
)
from app.api.v1.router import (
    api_router,
)
from app.modules.auth.router import router as auth_router
from app.modules.career.router import router as career_router
from app.modules.developer_portal.router import (

    router as developer_portal_router,

)
from app.modules.matchmaking.router import (
    router as matchmaking_router,
)
from app.modules.tournament.router import (
    router as tournament_router,
)
from app.modules.auth.router import (
    router as auth_router,
)
# Create Tables
Base.metadata.create_all(bind=engine)

settings = get_settings()

app = FastAPI(
    title="SkillBattle API",
    version="2.0.0",
    description="Enterprise AI Coding Platform Backend",
    docs_url="/docs",
    redoc_url="/redoc",
    tags_metadata = [
    {
        "name": "Battle",
        "description": "Battle Arena APIs",
    },
    {
        "name": "Tournament",
        "description": "Tournament APIs",
    },
    {
        "name": "AI",
        "description": "Artificial Intelligence APIs",
    },
    {
        "name": "Developer",
        "description": "Developer Platform APIs",
    },
]
)

# -----------------------------
# Middleware
# -----------------------------

app.middleware("http")(request_timer)
app.middleware("http")(add_request_id)

app.add_middleware(RequestLoggerMiddleware)

Base.metadata.create_all(bind=engine)
# -----------------------------
# CORS
# -----------------------------

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# Routers
# -----------------------------
app.include_router(achievements_router)
app.include_router(auth_router)
app.include_router(profile_router)
app.include_router(dashboard_router_module)
app.include_router(xp_router)
app.include_router(streak_router)
app.include_router(ai_router)
app.include_router(roadmap_router)
app.include_router(interview_router)
app.include_router(auth_router)
app.include_router(profile_router)
app.include_router(roadmap_router)
app.include_router(interview_router)
app.include_router(compiler_router)
app.include_router(battle_router)
app.include_router(tournament_router)
app.include_router(problem_generator_router)
app.include_router(code_review_router)
app.include_router(battle_coach_router)
app.include_router(learning_engine_router)
app.include_router(anti_cheat_router)
app.include_router(recruiter_router)
app.include_router(developer_router)
app.include_router(api_router)
app.include_router(analytics_router)
app.include_router(developer_portal_router)
app.include_router(battle_router)
app.include_router(matchmaking_router)
app.include_router(tournament_router)
app.include_router(analytics_router)
app.include_router(auth_router)
app.include_router(auth_router)

app.include_router(career_router)
# -----------------------------
# Exception Handlers
# -----------------------------

@app.exception_handler(SkillBattleException)
async def skillbattle_exception_handler(
    request: Request,
    exc: SkillBattleException,
):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.message,
            "path": request.url.path,
        },
    )


@app.exception_handler(Exception)
async def global_exception_handler(
    request: Request,
    exc: Exception,
):
    print(exc)

    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "message": "Internal Server Error",
            "path": request.url.path,
        },
    )

# -----------------------------
# Routes
# -----------------------------

@app.get("/")
def root():
    return {
        "success": True,
        "message": "Welcome to SkillBattle API 🚀",
        "version": "2.0.0",
    }


@app.get("/health")
def health():
    return {
        "success": True,
        "status": "healthy",
        "database": "connected",
    }


@app.get("/healthz")
def healthz():
    return {
        "success": True,
        "status": "ok",
        "service": "backend",
    }