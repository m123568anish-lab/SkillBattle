import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean,
    DateTime,
    Integer,
    String,
)

from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(
        String(36),
        primary_key=True,
        default=lambda: str(uuid.uuid4()),
    )

    username: Mapped[str] = mapped_column(
        String(30),
        unique=True,
        index=True,
        nullable=False,
    )

    full_name: Mapped[str] = mapped_column(
        String(120),
        nullable=False,
    )

    email: Mapped[str] = mapped_column(
        String(255),
        unique=True,
        index=True,
        nullable=False,
    )

    password_hash: Mapped[str] = mapped_column(
        String(255),
        nullable=False,
    )

    role: Mapped[str] = mapped_column(
        String(50),
        default="user",
        nullable=False,
    )

    avatar_url: Mapped[str | None] = mapped_column(
        String(500),
        default=None,
        nullable=True,
    )

    bio: Mapped[str | None] = mapped_column(
        String(1000),
        default="",
        nullable=True,
    )

    country: Mapped[str | None] = mapped_column(
        String(100),
        default="",
        nullable=True,
    )

    city: Mapped[str | None] = mapped_column(
        String(100),
        default="",
        nullable=True,
    )

    website: Mapped[str | None] = mapped_column(
        String(500),
        default="",
        nullable=True,
    )

    github_url: Mapped[str | None] = mapped_column(
        String(500),
        default="",
        nullable=True,
    )

    linkedin_url: Mapped[str | None] = mapped_column(
        String(500),
        default="",
        nullable=True,
    )

    login_count: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    coding_rating: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    placement_score: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    resume_score: Mapped[int] = mapped_column(
        Integer,
        default=0,
        nullable=False,
    )

    is_active: Mapped[bool] = mapped_column(
        Boolean,
        default=True,
    )

    is_verified: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
    )

    is_superuser: Mapped[bool] = mapped_column(
        Boolean,
        default=False,
        nullable=False,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
    )

    refresh_tokens = relationship(
        "RefreshToken",
        back_populates="user",
        cascade="all, delete-orphan",
    )

    def __repr__(self):
        return f"<User {self.email}>"