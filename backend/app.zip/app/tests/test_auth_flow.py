import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as client:
        yield client


def test_register_and_login_flow(client):
    payload = {
        "username": "demoauth",
        "email": "demoauth@example.com",
        "full_name": "Demo Auth",
        "password": "demo12345",
    }

    register_response = client.post("/auth/register", json=payload)
    assert register_response.status_code in {201, 400}

    login_response = client.post(
        "/auth/login",
        json={"email": payload["email"], "password": payload["password"]},
    )
    assert login_response.status_code in {200, 401}
