"""
=========================================================

SkillBattle

Career Router

=========================================================
"""
from app.modules.career.api.analysis import (
    router as analysis_router,
)
from fastapi import APIRouter

from app.modules.career.api.upload import router as upload_router

router = APIRouter()

router.include_router(upload_router)
router.include_router(analysis_router)