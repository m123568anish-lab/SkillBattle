class SkillBattleException(Exception):
	"""Application-specific exception with an attached HTTP status code."""

	def __init__(self, message: str, status_code: int = 400):
		self.message = message
		self.status_code = status_code
		super().__init__(message)

__all__ = ["SkillBattleException"]
