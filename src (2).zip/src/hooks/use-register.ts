"use client";

import { useState } from "react";
import { authService } from "@/services/auth.service";
import { RegisterRequest } from "@/types/auth";

export function useRegister() {

    const [loading, setLoading] =
        useState(false);

    async function signUp(
        data: RegisterRequest
    ) {

        setLoading(true);

        try {

            return await authService.register(
                data
            );

        } finally {

            setLoading(false);

        }

    }

    return {

        loading,

        signUp,

    };

}