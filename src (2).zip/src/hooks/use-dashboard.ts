"use client";

import { useDashboardStore }

from "@/store/dashboardStore";

export function useDashboard(){

    return useDashboardStore();

}