"use client";

import { useState } from "react";
import { useAuthStore } from "@/store/authStore";
import { LoginRequest } from "@/types/auth";

export function useLogin() {

    const login = useAuthStore(
        (state) => state.login
    );

    const [loading, setLoading] =
        useState(false);

    async function signIn(
        data: LoginRequest
    ) {

        setLoading(true);

        try {

            await login(data);

            return {

                success: true,

                tokens: {
                    access_token:
                        localStorage.getItem(
                            "access_token"
                        ),
                },

            };

        } finally {

            setLoading(false);

        }

    }

    return {

        loading,

        signIn,

    };

}