"use client";

import { motion } from "framer-motion";
import {
  Target,
  ArrowRight,
  Zap,
} from "lucide-react";

import GradientButton from "@/components/ui/gradient-button";

import BattleArenaCard from "./BattleArenaCard";
import LeaderboardWidget from "./LeaderboardWidget";
import AchievementWidget from "./AchievementWidget";
import CalendarHeatmap from "./CalendarHeatmap";

import type {
  DailyChallenge as DailyChallengeType,
} from "@/types/dashboard";

interface DailyChallengeProps {
  challenge: DailyChallengeType;
}

export default function DailyChallenge({
  challenge,
}: DailyChallengeProps) {
  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="
        rounded-3xl
        border
        border-white/10
        bg-white/5
        p-8
      "
    >
      {/* Header */}

      <div className="flex items-center gap-4">
        <div className="rounded-2xl bg-orange-500/20 p-4">
          <Target
            size={30}
            className="text-orange-400"
          />
        </div>

        <div>
          <h2 className="text-2xl font-black text-white">
            Today's Challenge
          </h2>

          <p className="text-slate-400">
            Daily coding mission
          </p>
        </div>
      </div>

      {/* Challenge Card */}

      <div className="mt-8 rounded-2xl bg-white/5 p-6">

        <div className="flex items-center justify-between">

          <h3 className="text-xl font-bold text-white">
            {challenge.title}
          </h3>

          <span className="rounded-full bg-green-500/20 px-3 py-1 text-green-300">
            {challenge.difficulty}
          </span>

        </div>

        <p className="mt-4 text-slate-400">
          {challenge.description}
        </p>

        <div className="mt-6 flex items-center gap-3">

          <Zap
            size={20}
            className="text-yellow-400"
          />

          <span className="font-semibold text-yellow-300">
            +{challenge.xp_reward} XP Reward
          </span>

        </div>

      </div>

      {/* Action Button */}

      <div className="mt-8">

        <GradientButton>

          Start Challenge

          <ArrowRight
            size={18}
            className="ml-2"
          />

        </GradientButton>

      </div>

      {/* Battle + Leaderboard */}

      <div className="mt-8 grid gap-8 xl:grid-cols-2">

        <BattleArenaCard />

        <LeaderboardWidget />

      </div>

      {/* Calendar + Achievements */}

      <div className="mt-8 grid gap-8 xl:grid-cols-2">

        <CalendarHeatmap />

        <AchievementWidget />

      </div>

    </motion.div>
  );
}