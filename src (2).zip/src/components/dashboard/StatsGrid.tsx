"use client";

import { motion } from "framer-motion";
import {
  Trophy,
  Target,
  Flame,
  Gem,
} from "lucide-react";

import type { DashboardStats } from "@/types/dashboard";

interface StatsGridProps {
  stats: DashboardStats;
}

export default function StatsGrid({
  stats,
}: StatsGridProps) {

  const winRate =
    stats.battles_played === 0
      ? 0
      : Math.round(
          (stats.battles_won / stats.battles_played) * 100
        );

  const cards = [
    {
      title: "Battles Won",
      value: stats.battles_won,
      icon: Trophy,
      color: "text-cyan-400",
    },
    {
      title: "Win Rate",
      value: `${winRate}%`,
      icon: Target,
      color: "text-green-400",
    },
    {
      title: "Current Streak",
      value: stats.streak,
      icon: Flame,
      color: "text-orange-400",
    },
    {
      title: "Total XP",
      value: stats.xp.toLocaleString(),
      icon: Gem,
      color: "text-violet-400",
    },
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">

      {cards.map((card) => {

        const Icon = card.icon;

        return (
          <motion.div
            key={card.title}
            whileHover={{
              y: -6,
              scale: 1.02,
            }}
            className="
              rounded-3xl
              border
              border-white/10
              bg-white/5
              p-6
              transition-all
            "
          >
            <div className="flex items-center justify-between">

              <div>

                <p className="text-sm text-slate-400">
                  {card.title}
                </p>

                <h2 className="mt-3 text-4xl font-black text-white">
                  {card.value}
                </h2>

              </div>

              <div className="rounded-2xl bg-white/5 p-4">

                <Icon
                  size={30}
                  className={card.color}
                />

              </div>

            </div>

          </motion.div>
        );
      })}

    </div>
  );
}