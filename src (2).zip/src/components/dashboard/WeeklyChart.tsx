"use client";

import { motion } from "framer-motion";

import type {
  WeeklyActivity,
} from "@/types/dashboard";

interface WeeklyChartProps {
  data: WeeklyActivity[];
}

export default function WeeklyChart({
  data,
}: WeeklyChartProps) {

  const max =
    Math.max(
      ...data.map((d) => d.xp),
      1
    );

  const totalXP =
    data.reduce(
      (sum, item) => sum + item.xp,
      0
    );

  return (
    <motion.div
      whileHover={{
        y: -4,
      }}
      className="
        rounded-3xl
        border
        border-white/10
        bg-white/5
        p-8
      "
    >
      <h2 className="text-2xl font-black text-white">
        Weekly Activity
      </h2>

      <p className="mt-2 text-slate-400">
        XP earned this week
      </p>

      <div className="mt-10 flex h-64 items-end justify-between gap-4">

        {data.map((item) => (

          <div
            key={item.day}
            className="flex flex-1 flex-col items-center"
          >

            <motion.div
              initial={{
                height: 0,
              }}
              animate={{
                height: `${(item.xp / max) * 180}px`,
              }}
              transition={{
                duration: 0.8,
              }}
              className="
                w-full
                rounded-t-xl
                bg-gradient-to-t
                from-cyan-500
                to-violet-500
              "
            />

            <span className="mt-3 text-sm text-slate-400">
              {item.day}
            </span>

          </div>

        ))}

      </div>

      <div className="mt-6 flex justify-between text-sm">

        <span className="text-slate-400">
          Total XP
        </span>

        <span className="font-semibold text-cyan-400">
          {totalXP.toLocaleString()}
        </span>

      </div>

    </motion.div>
  );
}