"use client";

import { motion } from "framer-motion";
import {
  Flame,
  Trophy,
  Star,
  Target,
} from "lucide-react";

import XPProgress from "./XPProgress";

import type {
  UserSummary,
  DashboardStats,
} from "@/types/dashboard";

interface DashboardHeroProps {
  user: UserSummary;
  stats: DashboardStats;
}

export default function DashboardHero({
  user,
  stats,
}: DashboardHeroProps) {
  const hour = new Date().getHours();

  let greeting = "Good Evening";

  if (hour < 12) greeting = "Good Morning";
  else if (hour < 18) greeting = "Good Afternoon";

  return (
    <motion.section
      initial={{
        opacity: 0,
        y: 25,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      transition={{
        duration: 0.6,
      }}
      className="
        rounded-3xl
        border
        border-white/10
        bg-gradient-to-br
        from-cyan-500/10
        via-slate-900
        to-violet-500/10
        p-8
      "
    >
      <div className="flex flex-col gap-10 lg:flex-row lg:items-center lg:justify-between">

        {/* Left */}

        <div>

          <p className="text-lg text-slate-400">
            {greeting},
          </p>

          <h1 className="mt-2 text-5xl font-black text-white">
            {user.full_name} 👋
          </h1>

          <p className="mt-2 text-cyan-400">
            @{user.username}
          </p>

          <p className="mt-2 text-slate-400">
            {user.email}
          </p>

          <p className="mt-4 max-w-xl text-slate-400">
            Welcome back! Continue your preparation and move one step closer to your dream company.
          </p>

          <div className="mt-6">

            <XPProgress
              currentXP={stats.xp}
              nextLevelXP={(stats.level + 1) * 2500}
            />

          </div>

        </div>

        {/* Right */}

        <div className="grid gap-5 sm:grid-cols-2">

          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">

            <Star className="mb-3 text-yellow-400" />

            <p className="text-sm text-slate-400">
              Level
            </p>

            <h2 className="mt-2 text-3xl font-black text-white">
              {stats.level}
            </h2>

          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">

            <Flame className="mb-3 text-orange-400" />

            <p className="text-sm text-slate-400">
              Daily Streak
            </p>

            <h2 className="mt-2 text-3xl font-black text-white">
              {stats.streak} Days
            </h2>

          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">

            <Trophy className="mb-3 text-cyan-400" />

            <p className="text-sm text-slate-400">
              Rating
            </p>

            <h2 className="mt-2 text-3xl font-black text-white">
              {stats.rating}
            </h2>

          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">

            <Target className="mb-3 text-green-400" />

            <p className="text-sm text-slate-400">
              Battles Played
            </p>

            <h2 className="mt-2 text-3xl font-black text-white">
              {stats.battles_played}
            </h2>

          </div>

        </div>

      </div>
    </motion.section>
  );
}