"use client";

import DashboardLayout from "@/components/dashboard/DashboardLayout";

import DashboardHero from "@/components/dashboard/DashboardHero";
import StatsGrid from "@/components/dashboard/StatsGrid";
import WeeklyChart from "@/components/dashboard/WeeklyChart";
import AICoachCard from "@/components/dashboard/AICoachCard";
import DailyChallenge from "@/components/dashboard/DailyChallenge";

import { useDashboard } from "@/hooks/use-dashboard";

export default function DashboardPage() {
  const {
    dashboard,
    loading,
    error,
    refresh,
  } = useDashboard();

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex h-[70vh] items-center justify-center">
          <div className="text-center">
            <div className="mx-auto h-12 w-12 animate-spin rounded-full border-4 border-cyan-500 border-t-transparent" />
            <p className="mt-5 text-slate-400">
              Loading dashboard...
            </p>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (error) {
    return (
      <DashboardLayout>
        <div className="flex h-[70vh] flex-col items-center justify-center gap-5">
          <h2 className="text-2xl font-bold">
            Unable to load dashboard
          </h2>

          <p className="text-slate-400">
            {error}
          </p>

          <button
            onClick={refresh}
            className="rounded-xl bg-cyan-500 px-6 py-3 font-semibold"
          >
            Retry
          </button>
        </div>
      </DashboardLayout>
    );
  }

  if (!dashboard) {
    return null;
  }

  return (
    <DashboardLayout>

      <DashboardHero
       user={dashboard.user}
       stats={dashboard.stats}
/>

      <div className="mt-8">

        <StatsGrid
          stats={dashboard.stats}
        />

      </div>

      <div className="mt-8 grid gap-8 xl:grid-cols-2">

        <WeeklyChart
          data={dashboard.weekly_activity}
        />

      <AICoachCard
    recommendation={dashboard.ai_recommendation}
/>

      </div>

      <div className="mt-8">

        <DailyChallenge />

      </div>

    </DashboardLayout>
  );
}