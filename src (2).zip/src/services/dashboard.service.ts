import { api } from "@/lib/api";

export interface DashboardStats {

    profile: {

        id: string;

        full_name: string;

        email: string;

        avatar?: string;

        role: string;

    };

    stats: {

        xp: number;

        rating: number;

        level: number;

        battles: number;

        wins: number;

        tournaments: number;

        solved_problems: number;

    };

    recent_activity: any[];

    notifications: number;

}

class DashboardService {

    async getDashboard() {

        const response = await api.get<DashboardStats>(

            "/dashboard"

        );

        return response.data;

    }

}

export const dashboardService =

    new DashboardService();