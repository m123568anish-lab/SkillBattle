import { create } from "zustand";

import {

    dashboardService,

    DashboardStats,

} from "@/services/dashboard.service";

interface DashboardState {

    dashboard:

        DashboardStats | null;

    loading: boolean;

    loadDashboard():

        Promise<void>;

}

export const useDashboardStore =

create<DashboardState>(

(set)=>({

    dashboard:null,

    loading:false,

    async loadDashboard(){

        set({

            loading:true,

        });

        try{

            const data=

                await dashboardService

                .getDashboard();

            set({

                dashboard:data,

                loading:false,

            });

        }

        catch{

            set({

                loading:false,

            });

        }

    }

}));