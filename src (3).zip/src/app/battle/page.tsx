export default function BattlePage() {
    return (
        <div className="p-8">
            <h1 className="text-3xl font-bold">Battle Arena</h1>
            <p>Coming Soon...</p>
        </div>
    );
}