"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

interface Props {
  title: string;
  variant?: "default" | "ghost";
}

export default function NavButton({
  title,
  variant = "default",
}: Props) {
  const router = useRouter();

  const handleClick = () => {
    if (title === "Login") {
      router.push("/login");
    } else if (title === "Start Battle") {
      router.push("/battle");
    }
  };

  return (
    <Button
      onClick={handleClick}
      variant={variant}
      className={
        variant === "default"
          ? "bg-violet-600 hover:bg-violet-700 cursor-pointer"
          : "cursor-pointer"
      }
    >
      {title}
    </Button>
  );
}