import API from "@/lib/api";
import {
  Roadmap,
  RoadmapCreate,
  RoadmapUpdate,
} from "@/types/roadmap";

class RoadmapService {
  async getUserRoadmap(userId: string): Promise<Roadmap> {
    const response = await API.get(`/api/v1/roadmap/${userId}`);
    return response.data;
  }

  async createRoadmap(data: RoadmapCreate): Promise<Roadmap> {
    const response = await API.post("/api/v1/roadmap", data);
    return response.data;
  }

  async updateRoadmap(
    roadmapId: string,
    data: RoadmapUpdate
  ): Promise<Roadmap> {
    const response = await API.put(`/api/v1/roadmap/${roadmapId}`, data);
    return response.data;
  }

  async completeRoadmapTask(
    roadmapId: string,
    taskId: string
  ): Promise<any> {
    const response = await API.post(
      `/api/v1/roadmap/${roadmapId}/task/${taskId}/complete`,
      {}
    );
    return response.data;
  }

  async getRoadmapTasks(roadmapId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/roadmap/${roadmapId}/tasks`
    );
    return response.data;
  }

  async getRecommendedRoadmap(userId: string): Promise<Roadmap> {
    const response = await API.get(
      `/api/v1/roadmap/recommended/${userId}`
    );
    return response.data;
  }

  async trackProgress(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/roadmap/${userId}/progress`
    );
    return response.data;
  }
}

export default new RoadmapService();
