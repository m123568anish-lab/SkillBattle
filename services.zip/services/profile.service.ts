import API from "@/lib/api";
import { UserProfile, ProfileUpdate } from "@/types/profile";

class ProfileService {
  async getUserProfile(userId: string): Promise<UserProfile> {
    const response = await API.get(`/api/v1/profile/${userId}`);
    return response.data;
  }

  async getCurrentUserProfile(): Promise<UserProfile> {
    const response = await API.get("/api/v1/profile/me");
    return response.data;
  }

  async updateProfile(userId: string, data: ProfileUpdate): Promise<UserProfile> {
    const response = await API.put(`/api/v1/profile/${userId}`, data);
    return response.data;
  }

  async getProfileStats(userId: string): Promise<any> {
    const response = await API.get(`/api/v1/profile/${userId}/stats`);
    return response.data;
  }

  async uploadAvatar(userId: string, file: File): Promise<any> {
    const formData = new FormData();
    formData.append("file", file);
    const response = await API.post(`/api/v1/profile/${userId}/avatar`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  }
}

export default new ProfileService();
