import API from "@/lib/api";
import { API_ENDPOINTS } from "@/lib/api-constants";
import {
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  User,
  RefreshTokenRequest,
} from "@/types/auth";

class AuthService {
  async register(data: RegisterRequest): Promise<User> {
    const response = await API.post(
      API_ENDPOINTS.AUTH.REGISTER,
      data
    );
    return response.data;
  }

  async login(data: LoginRequest): Promise<LoginResponse> {
    const response = await API.post(
      API_ENDPOINTS.AUTH.LOGIN,
      data
    );

    const result = response.data;

    localStorage.setItem(
      "access_token",
      result.tokens.access_token
    );

    localStorage.setItem(
      "refresh_token",
      result.tokens.refresh_token
    );

    localStorage.setItem(
      "expires_in",
      result.tokens.expires_in.toString()
    );

    return result;
  }

  async logout(): Promise<void> {
    const refresh_token = localStorage.getItem(
      "refresh_token"
    );

    if (refresh_token) {
      try {
        await API.post(API_ENDPOINTS.AUTH.LOGOUT, {
          refresh_token,
        });
      } catch {
        // Ignore logout API errors
      }
    }

    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    localStorage.removeItem("expires_in");
  }

  async refreshToken(
    refreshToken: string
  ): Promise<LoginResponse> {
    const response = await API.post(
      API_ENDPOINTS.AUTH.REFRESH,
      { refresh_token: refreshToken }
    );

    const result = response.data;

    localStorage.setItem(
      "access_token",
      result.tokens.access_token
    );

    localStorage.setItem(
      "refresh_token",
      result.tokens.refresh_token
    );

    return result;
  }

  async getCurrentUser(): Promise<User> {
    const response = await API.get(API_ENDPOINTS.AUTH.ME);
    return response.data;
  }

  async changePassword(
    current_password: string,
    new_password: string
  ): Promise<any> {
    return API.post("/auth/change-password", {
      current_password,
      new_password,
    });
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem("access_token");
  }

  getAccessToken(): string | null {
    return localStorage.getItem("access_token");
  }

  getRefreshToken(): string | null {
    return localStorage.getItem("refresh_token");
  }
}

export default new AuthService();