import API from "@/lib/api";
import {
  CodeReview,
  CodeReviewCreate,
  ReviewComment,
} from "@/types/code-review";

class CodeReviewService {
  async createCodeReview(data: CodeReviewCreate): Promise<CodeReview> {
    const response = await API.post("/api/v1/code-review", data);
    return response.data;
  }

  async getCodeReview(reviewId: string): Promise<CodeReview> {
    const response = await API.get(`/api/v1/code-review/${reviewId}`);
    return response.data;
  }

  async submitCodeForReview(
    code: string,
    language: string,
    description?: string
  ): Promise<CodeReview> {
    const response = await API.post("/api/v1/code-review/submit", {
      code,
      language,
      description,
    });
    return response.data;
  }

  async addComment(
    reviewId: string,
    lineNumber: number,
    comment: string
  ): Promise<ReviewComment> {
    const response = await API.post(
      `/api/v1/code-review/${reviewId}/comment`,
      { line_number: lineNumber, comment }
    );
    return response.data;
  }

  async getReviewComments(reviewId: string): Promise<ReviewComment[]> {
    const response = await API.get(
      `/api/v1/code-review/${reviewId}/comments`
    );
    return response.data;
  }

  async completeReview(reviewId: string, feedback: string): Promise<any> {
    const response = await API.post(
      `/api/v1/code-review/${reviewId}/complete`,
      { feedback }
    );
    return response.data;
  }

  async getUserCodeReviews(userId: string): Promise<CodeReview[]> {
    const response = await API.get(`/api/v1/code-review/user/${userId}`);
    return response.data;
  }
}

export default new CodeReviewService();
