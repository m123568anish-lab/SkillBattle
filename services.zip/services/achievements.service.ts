import API from "@/lib/api";
import { Achievement } from "@/types/achievement";

class AchievementsService {
  async getUserAchievements(userId: string): Promise<Achievement[]> {
    const response = await API.get(
      `/api/v1/achievements/${userId}`
    );
    return response.data;
  }

  async getAllAchievements(): Promise<Achievement[]> {
    const response = await API.get("/api/v1/achievements");
    return response.data;
  }

  async unlockAchievement(
    userId: string,
    achievementId: string
  ): Promise<Achievement> {
    const response = await API.post(
      `/api/v1/achievements/${userId}/unlock`,
      { achievement_id: achievementId }
    );
    return response.data;
  }

  async getAchievementDetails(achievementId: string): Promise<Achievement> {
    const response = await API.get(
      `/api/v1/achievements/${achievementId}`
    );
    return response.data;
  }

  async getRecentAchievements(userId: string, limit: number = 5): Promise<Achievement[]> {
    const response = await API.get(
      `/api/v1/achievements/${userId}/recent`,
      { params: { limit } }
    );
    return response.data;
  }

  async getAchievementProgress(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/achievements/${userId}/progress`
    );
    return response.data;
  }
}

export default new AchievementsService();
