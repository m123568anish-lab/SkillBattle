import API from "@/lib/api";
import {
  Challenge,
  ChallengeCreate,
  ChallengeUpdate,
} from "@/types/challenge";

class ChallengeService {
  async createChallenge(data: ChallengeCreate): Promise<Challenge> {
    const response = await API.post(
      "/api/v1/problem-generator",
      data
    );
    return response.data;
  }

  async getChallenge(challengeId: string): Promise<Challenge> {
    const response = await API.get(
      `/api/v1/problem-generator/${challengeId}`
    );
    return response.data;
  }

  async updateChallenge(
    challengeId: string,
    data: ChallengeUpdate
  ): Promise<Challenge> {
    const response = await API.put(
      `/api/v1/problem-generator/${challengeId}`,
      data
    );
    return response.data;
  }

  async getChallenges(
    limit: number = 20,
    offset: number = 0
  ): Promise<Challenge[]> {
    const response = await API.get(
      "/api/v1/problem-generator",
      {
        params: { limit, offset },
      }
    );
    return response.data;
  }

  async getChallengesByDifficulty(
    difficulty: string
  ): Promise<Challenge[]> {
    const response = await API.get(
      "/api/v1/problem-generator",
      {
        params: { difficulty },
      }
    );
    return response.data;
  }

  async submitChallengeSolution(
    challengeId: string,
    solution: string
  ): Promise<any> {
    const response = await API.post(
      `/api/v1/problem-generator/${challengeId}/submit`,
      { solution }
    );
    return response.data;
  }

  async generateChallenge(params: any): Promise<Challenge> {
    const response = await API.post(
      "/api/v1/problem-generator/generate",
      params
    );
    return response.data;
  }

  async getTestCases(challengeId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/problem-generator/${challengeId}/test-cases`
    );
    return response.data;
  }
}

export default new ChallengeService();
