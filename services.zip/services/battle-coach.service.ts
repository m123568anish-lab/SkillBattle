import API from "@/lib/api";

class BattleCoachService {
  async getCoachRecommendations(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/battle-coach/${userId}/recommendations`
    );
    return response.data;
  }

  async analyzeBattlePerformance(battleId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/battle-coach/battle/${battleId}/analysis`
    );
    return response.data;
  }

  async getCoachingSession(sessionId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/battle-coach/session/${sessionId}`
    );
    return response.data;
  }

  async startCoachingSession(userId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/battle-coach/${userId}/session`,
      {}
    );
    return response.data;
  }

  async getCoachingFeedback(
    userId: string,
    challengeId: string
  ): Promise<any> {
    const response = await API.get(
      `/api/v1/battle-coach/${userId}/feedback/${challengeId}`
    );
    return response.data;
  }

  async getSuggestedPracticeProblems(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/battle-coach/${userId}/practice`
    );
    return response.data;
  }
}

export default new BattleCoachService();
