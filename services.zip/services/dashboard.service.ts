import API from "@/lib/api";
import { DashboardData, DashboardStats } from "@/types/dashboard";

class DashboardService {
  async getDashboard(): Promise<DashboardData> {
    const response = await API.get("/api/v1/dashboard");
    return response.data;
  }

  async getDashboardStats(): Promise<DashboardStats> {
    const response = await API.get("/api/v1/dashboard/stats");
    return response.data;
  }

  async getUserActivity(userId: string): Promise<any> {
    const response = await API.get(`/api/v1/dashboard/${userId}/activity`);
    return response.data;
  }

  async getRecentBattles(limit: number = 10): Promise<any> {
    const response = await API.get("/api/v1/dashboard/battles", {
      params: { limit },
    });
    return response.data;
  }

  async getLeaderboard(limit: number = 100): Promise<any> {
    const response = await API.get("/api/v1/dashboard/leaderboard", {
      params: { limit },
    });
    return response.data;
  }
}

export default new DashboardService();
