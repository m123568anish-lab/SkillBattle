import API from "@/lib/api";
import {
  Battle,
  BattleCreate,
  BattleUpdate,
  BattleResult,
} from "@/types/battle";

class BattleService {
  async createBattle(data: BattleCreate): Promise<Battle> {
    const response = await API.post("/api/v1/battle", data);
    return response.data;
  }

  async getBattle(battleId: string): Promise<Battle> {
    const response = await API.get(`/api/v1/battle/${battleId}`);
    return response.data;
  }

  async updateBattle(
    battleId: string,
    data: BattleUpdate
  ): Promise<Battle> {
    const response = await API.put(`/api/v1/battle/${battleId}`, data);
    return response.data;
  }

  async joinBattle(battleId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/battle/${battleId}/join`,
      {}
    );
    return response.data;
  }

  async leaveBattle(battleId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/battle/${battleId}/leave`,
      {}
    );
    return response.data;
  }

  async submitSolution(
    battleId: string,
    solution: string
  ): Promise<any> {
    const response = await API.post(
      `/api/v1/battle/${battleId}/submit`,
      { solution }
    );
    return response.data;
  }

  async getBattleResult(battleId: string): Promise<BattleResult> {
    const response = await API.get(
      `/api/v1/battle/${battleId}/result`
    );
    return response.data;
  }

  async getUserBattles(userId: string): Promise<Battle[]> {
    const response = await API.get(
      `/api/v1/battle/user/${userId}`
    );
    return response.data;
  }

  async getActiveBattles(): Promise<Battle[]> {
    const response = await API.get("/api/v1/battle/active");
    return response.data;
  }

  async endBattle(battleId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/battle/${battleId}/end`,
      {}
    );
    return response.data;
  }
}

export default new BattleService();
