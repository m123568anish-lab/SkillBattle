import API from "@/lib/api";
import {
  Tournament,
  TournamentCreate,
  TournamentUpdate,
} from "@/types/tournament";

class TournamentService {
  async createTournament(data: TournamentCreate): Promise<Tournament> {
    const response = await API.post("/api/v1/tournament", data);
    return response.data;
  }

  async getTournament(tournamentId: string): Promise<Tournament> {
    const response = await API.get(`/api/v1/tournament/${tournamentId}`);
    return response.data;
  }

  async updateTournament(
    tournamentId: string,
    data: TournamentUpdate
  ): Promise<Tournament> {
    const response = await API.put(
      `/api/v1/tournament/${tournamentId}`,
      data
    );
    return response.data;
  }

  async registerTournament(tournamentId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/tournament/${tournamentId}/register`,
      {}
    );
    return response.data;
  }

  async unregisterTournament(tournamentId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/tournament/${tournamentId}/unregister`,
      {}
    );
    return response.data;
  }

  async getTournamentBracket(tournamentId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/tournament/${tournamentId}/bracket`
    );
    return response.data;
  }

  async getTournamentParticipants(
    tournamentId: string
  ): Promise<any> {
    const response = await API.get(
      `/api/v1/tournament/${tournamentId}/participants`
    );
    return response.data;
  }

  async getUpcomingTournaments(): Promise<Tournament[]> {
    const response = await API.get("/api/v1/tournament/upcoming");
    return response.data;
  }

  async getActiveTournaments(): Promise<Tournament[]> {
    const response = await API.get("/api/v1/tournament/active");
    return response.data;
  }

  async startTournament(tournamentId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/tournament/${tournamentId}/start`,
      {}
    );
    return response.data;
  }

  async endTournament(tournamentId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/tournament/${tournamentId}/end`,
      {}
    );
    return response.data;
  }
}

export default new TournamentService();
