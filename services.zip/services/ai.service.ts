import API from "@/lib/api";

class AIService {
  async generateProblem(params: any): Promise<any> {
    const response = await API.post("/api/v1/ai/generate-problem", params);
    return response.data;
  }

  async analyzeCode(code: string, language: string): Promise<any> {
    const response = await API.post("/api/v1/ai/analyze-code", {
      code,
      language,
    });
    return response.data;
  }

  async generateFeedback(
    solution: string,
    language: string,
    challengeId: string
  ): Promise<any> {
    const response = await API.post("/api/v1/ai/generate-feedback", {
      solution,
      language,
      challenge_id: challengeId,
    });
    return response.data;
  }

  async suggestImprovement(code: string): Promise<any> {
    const response = await API.post(
      "/api/v1/ai/suggest-improvement",
      { code }
    );
    return response.data;
  }

  async getAIRecommendations(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/ai/recommendations/${userId}`
    );
    return response.data;
  }

  async generateCodingPath(userId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/ai/generate-path/${userId}`,
      {}
    );
    return response.data;
  }
}

export default new AIService();
