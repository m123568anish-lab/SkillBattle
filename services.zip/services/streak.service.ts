import API from "@/lib/api";
import { Streak } from "@/types/streak";

class StreakService {
  async getUserStreak(userId: string): Promise<Streak> {
    const response = await API.get(`/api/v1/streak/${userId}`);
    return response.data;
  }

  async recordActivity(userId: string): Promise<Streak> {
    const response = await API.post(`/api/v1/streak/${userId}/record`, {});
    return response.data;
  }

  async getStreakHistory(userId: string): Promise<any> {
    const response = await API.get(`/api/v1/streak/${userId}/history`);
    return response.data;
  }

  async getTopStreaks(limit: number = 10): Promise<Streak[]> {
    const response = await API.get("/api/v1/streak/leaderboard", {
      params: { limit },
    });
    return response.data;
  }

  async resetStreak(userId: string): Promise<any> {
    const response = await API.post(`/api/v1/streak/${userId}/reset`, {});
    return response.data;
  }

  async getStreakMilestones(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/streak/${userId}/milestones`
    );
    return response.data;
  }
}

export default new StreakService();
