import API from "@/lib/api";

class LearningEngineService {
  async getPersonalizedLearningPlan(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/learning-engine/${userId}/plan`
    );
    return response.data;
  }

  async generateLearningContent(topic: string): Promise<any> {
    const response = await API.post(
      "/api/v1/learning-engine/generate",
      { topic }
    );
    return response.data;
  }

  async getMostRecentLesson(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/learning-engine/${userId}/recent`
    );
    return response.data;
  }

  async trackLearningProgress(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/learning-engine/${userId}/progress`
    );
    return response.data;
  }

  async completeTopic(userId: string, topicId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/learning-engine/${userId}/complete`,
      { topic_id: topicId }
    );
    return response.data;
  }

  async getRecommendedTopics(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/learning-engine/${userId}/recommended`
    );
    return response.data;
  }
}

export default new LearningEngineService();
