import API from "@/lib/api";
import {
  Interview,
  InterviewCreate,
  InterviewUpdate,
} from "@/types/interview";

class InterviewService {
  async createInterview(data: InterviewCreate): Promise<Interview> {
    const response = await API.post("/api/v1/interview", data);
    return response.data;
  }

  async getInterview(interviewId: string): Promise<Interview> {
    const response = await API.get(`/api/v1/interview/${interviewId}`);
    return response.data;
  }

  async updateInterview(
    interviewId: string,
    data: InterviewUpdate
  ): Promise<Interview> {
    const response = await API.put(
      `/api/v1/interview/${interviewId}`,
      data
    );
    return response.data;
  }

  async startInterview(interviewId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/interview/${interviewId}/start`,
      {}
    );
    return response.data;
  }

  async submitAnswer(
    interviewId: string,
    questionId: string,
    answer: string
  ): Promise<any> {
    const response = await API.post(
      `/api/v1/interview/${interviewId}/submit-answer`,
      { question_id: questionId, answer }
    );
    return response.data;
  }

  async getInterviewQuestions(interviewId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/interview/${interviewId}/questions`
    );
    return response.data;
  }

  async getInterviewResult(interviewId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/interview/${interviewId}/result`
    );
    return response.data;
  }

  async endInterview(interviewId: string): Promise<any> {
    const response = await API.post(
      `/api/v1/interview/${interviewId}/end`,
      {}
    );
    return response.data;
  }
}

export default new InterviewService();
