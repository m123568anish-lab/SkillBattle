import API from "@/lib/api";

class CareerService {
  async getUserCareerProfile(userId: string): Promise<any> {
    const response = await API.get(`/api/v1/career/${userId}`);
    return response.data;
  }

  async updateCareerGoals(userId: string, goals: any): Promise<any> {
    const response = await API.put(
      `/api/v1/career/${userId}/goals`,
      goals
    );
    return response.data;
  }

  async getCareerPath(userId: string): Promise<any> {
    const response = await API.get(`/api/v1/career/${userId}/path`);
    return response.data;
  }

  async getMentorRecommendations(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/career/${userId}/mentors`
    );
    return response.data;
  }

  async getJobOpportunities(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/career/${userId}/opportunities`
    );
    return response.data;
  }

  async updateResume(userId: string, resumeData: any): Promise<any> {
    const response = await API.put(
      `/api/v1/career/${userId}/resume`,
      resumeData
    );
    return response.data;
  }

  async getCareerAnalytics(userId: string): Promise<any> {
    const response = await API.get(
      `/api/v1/career/${userId}/analytics`
    );
    return response.data;
  }
}

export default new CareerService();
