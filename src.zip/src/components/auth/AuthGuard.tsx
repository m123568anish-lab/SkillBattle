"use client";

import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";

interface AuthGuardProps {
  children: React.ReactNode;
}

const PUBLIC_ROUTES = [
  "/",
  "/login",
  "/register",
  "/forgot-password",
  "/verify-email",
  "/reset-password",
];

export function AuthGuard({ children }: AuthGuardProps) {
  const pathname = usePathname();
  const router = useRouter();

  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token =
          localStorage.getItem("accessToken") ??
          localStorage.getItem("access_token");

        const isPublic = PUBLIC_ROUTES.includes(pathname);

        if (!token) {
          if (!isPublic) {
            router.replace("/login");
            return;
          }

          setChecking(false);
          return;
        }

        // Prevent logged-in users from revisiting auth pages
        if (
          pathname === "/login" ||
          pathname === "/register"
        ) {
          router.replace("/dashboard");
          return;
        }

        setChecking(false);
      } catch (error) {
        console.error("Authentication check failed:", error);

        localStorage.removeItem("accessToken");
        localStorage.removeItem("access_token");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("refresh_token");

        router.replace("/login");
      }
    };

    checkAuth();
  }, [pathname, router]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#070B14]">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-cyan-500 border-t-transparent" />
          <p className="text-gray-400 text-sm">
            Checking authentication...
          </p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}