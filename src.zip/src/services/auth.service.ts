import api from "@/services/api";

import {
  LoginFormData,
  RegisterFormData,
} from "@/lib/validation";

export interface LoginResponse {
  user: any;
  tokens: {
    access_token: string;
    refresh_token: string;
    expires_in: number;
  };
}

class AuthService {
  async login(data: LoginFormData): Promise<LoginResponse> {
    const response = await api.post("/auth/login", {
      email: data.email,
      password: data.password,
    });

    const result = response.data;

    localStorage.setItem(
      "access_token",
      result.tokens.access_token
    );

    localStorage.setItem(
      "refresh_token",
      result.tokens.refresh_token
    );

    return result;
  }

  async register(data: RegisterFormData) {
    const response = await api.post("/auth/register", {
      username: data.name
        .trim()
        .toLowerCase()
        .replace(/\s+/g, "_"),

      full_name: data.name,

      email: data.email,

      password: data.password,
    });

    return response.data;
  }

  async getCurrentUser() {
    const response = await api.get("/auth/me");

    return response.data;
  }

  async logout() {
    try {
      const refreshToken =
        localStorage.getItem("refresh_token");

      if (refreshToken) {
        await api.post("/auth/logout", {
          refresh_token: refreshToken,
        });
      }
    } catch {
      // Ignore logout API failures
    }

    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");

    window.location.href = "/login";
  }

  isAuthenticated() {
    return !!localStorage.getItem("access_token");
  }
}

export const authService = new AuthService();