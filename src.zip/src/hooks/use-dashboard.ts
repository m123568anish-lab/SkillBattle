"use client";

import { useCallback, useEffect, useState } from "react";

import { dashboardService } from "@/services/dashboard.service";

import type {
  DashboardResponse,
} from "@/types/dashboard";

export function useDashboard() {
  const [dashboard, setDashboard] =
    useState<DashboardResponse | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState<string | null>(null);

  const loadDashboard =
    useCallback(async () => {
      try {
        setLoading(true);
        setError(null);

        const data =
          await dashboardService.getDashboard();

        setDashboard(data);
      } catch (err: any) {
        console.error(err);

        setError(
          err?.response?.data?.detail ??
          "Unable to load dashboard."
        );
      } finally {
        setLoading(false);
      }
    }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  return {
    dashboard,
    loading,
    error,
    refresh: loadDashboard,
  };
}