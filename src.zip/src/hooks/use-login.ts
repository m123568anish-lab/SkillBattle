"use client";

import { useState } from "react";
import { authService } from "@/services/auth.service";

export function useLogin() {
  const [loading, setLoading] = useState(false);

  async function signIn(data: {
    email: string;
    password: string;
  }) {
    try {
      setLoading(true);

      return await authService.login(data);
    } finally {
      setLoading(false);
    }
  }

  return {
    loading,
    signIn,
  };
}