"use client";

import { useState } from "react";
import { authService } from "@/services/auth.service";
import { RegisterFormData } from "@/lib/validation";

export function useRegister() {
  const [loading, setLoading] = useState(false);

  async function signUp(data: RegisterFormData) {
    try {
      setLoading(true);

      return await authService.register({
        username: data.email.split("@")[0],
        full_name: data.name,
        email: data.email,
        password: data.password,
      });
    } finally {
      setLoading(false);
    }
  }

  return {
    loading,
    signUp,
  };
}